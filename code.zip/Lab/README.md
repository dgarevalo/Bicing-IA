# practica-IA
