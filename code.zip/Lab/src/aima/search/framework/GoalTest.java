package aima.search.framework;

public interface GoalTest {
	boolean isGoalState(Object state);

}