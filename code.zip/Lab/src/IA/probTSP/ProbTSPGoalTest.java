package IA.probTSP;

import aima.search.framework.GoalTest;


public class ProbTSPGoalTest implements GoalTest {

  public boolean isGoalState(Object aState) {
    return(false);
  }

}
