/*
 *Pr�ctica de IA (B�squeda)
 * FIB - UPC
 * Curso 2006-2007
 * Cuatrimestre de Oto�o
 *
 * Daniel Garc�a P�rez
 * Sergio Vico Marfil
 *
 * DistribucionHeuristic.java
 *
 */

package IA.Electricidad;

import aima.search.framework.HeuristicFunction;


public class DistribucionHeuristic implements HeuristicFunction{
    
    public double getHeuristicValue(Object estado) {
        System.out.println("\nEntra y no deberia\n");
        return 0;
    }
    
}
